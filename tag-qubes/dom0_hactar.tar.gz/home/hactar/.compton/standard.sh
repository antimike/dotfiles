#!/bin/bash



# Compton autoload
# exec_always --no-startup-id compton -b --config $HOME/.config/compton.conf
compton -b --mark-ovredir-focused --backend="xrender" -f -i 0.85 -e 0.9 -r 10 -l -5 -t 0 -o 0.8 --shadow-red=0.11 --shadow-green=0.12 --shadow-blue=0.13 --shadow-exclude="name = 'Notification'" --shadow-exclude="!I3_FLOAATING_WINDOW@:c" --shadow-exclude="class_g = 'i3-frame'" --shadow-ignore-shaped --blur-background-fixed --blur-kern="7x7box" --blur-background-exclude="class_g = 'i3-frame'" --blur-background-exclude="window_type = 'dock'" --blur-background-exclude="window_type = 'desktop'" -D 1 -O 0.03 -I 0.03 --mark-wmwin-focused --detect-rounded-corners --detect-client-opacity --glx-no-stencil --detect-transient --opacity-rule "85:name *= 'Kitty'" --opacity-rule "85:name *= 'urxvt'" --opacity-rule "85:name *= ':~'" --opacity-rule "85:name *= 'fish'" --opacity-rule "85:name *= 'Qube Manager'" --opacity-rule "85:name *= 'Inkscape'" --opacity-rule "85:name *= 'Popup'"
# -b == daemonize
# -f == fade
# -i == opacity (inactive windows)
# -e == opacity (window titlebars / borders)
# -o == opacity (shadows)
# -r == blur radius (shadows)
# -D == fade-step delay (ms) (default == 10) (default == 10)
# -O == opacity change between steps during fadeout (default == 0.03)
# -I == opacity change between steps during fadein (default == 0.028)
# -o == translucency for shadows
# -l == left-offset (shadows) (default == -15)
# -r == blur radius (shadows) (default == 12)
# -t == top offset (shadows) (default == -15)
# -m == opacity (menus) (default == 1.0)
# -c == client-side shadows enabled on windows
# -C == don't draw shadows on dock / panel windows
# --shadow-red
# --shadow-green
# --shadow-blue
# --inactive-opacity-override
# --inactive-dim
# --active-opacity
# --mark-wmwin-focused
# --shadow-exclude [CONDITION]
# --fade-exclude [CONDITION]
# --no-fading-openclose
# --detect-rounded-corners
# --detect-client-opacity
# --refresh-rate
# --vsync [VSYNC_METHOD]
# --vsync-aggressive
# --dbe --> eliminates tearing (?); used with VSync
# --unredir-if-possible == optimized handling of fullscreen windows
# --blur-background --> bad performance
# --blur-kern [MATRIX]
# --blur-background-[frame/fixed]
# --resize-damage
# --invert-color-include [CONDITION] --> bad performance / not well tested
# --opacity-rule [VAL:CONDITION] --> e.g., '50:name *= "Firefox"'
# --backend
# --glx-no-stencil --> ~15% performance boost; may cause issues with transparent content
# xrender-sync-fence == use X Sync fence to sync draw calls; needed on NVIDIA + GLX backend sometimes

