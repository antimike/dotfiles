#!/bin/bash

killall compton
~/.compton/standard.sh
