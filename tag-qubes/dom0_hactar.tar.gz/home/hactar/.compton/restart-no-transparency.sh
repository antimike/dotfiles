#!/bin/bash

killall compton
~/.compton/no-transparency.sh

