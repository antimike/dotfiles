#!/bin/bash


#file=$(mktemp)
#COMMAND = "cat /usr/share/X11/${1}"

exec "qvm-run --pass-io disp6743 'cat /usr/include/X11/${1}' > ~/Downloads/tempfile.h"
exec "sudo mv ~/Downloads/tempfile.h /usr/include/X11/${1}"

#qvm-run --pass-io disp6743 $COMMAND > $file
#sudo mv $file "/usr/share/X11/${1}"
