#!/bin/bash

# Use the following command in DOM0 to retreive this file:
# qvm-run --pass-io qubes-builder-2 'cat /home/user/qubes-builder/qubes-src/linux-template-builder/rpm/install-templates.sh' > install-templates.sh

files="
qubes-template-bionic-desktop-4.0.1-202006080735.noarch.rpm 
"

path="/home/user/qubes-builder/qubes-src/linux-template-builder/rpm/noarch"
version="-4.0.1"
name="qubes-builder-2"

for file_name in ${files[@]}; do
    if echo "$file_name" | grep -q '^#' ; then
       continue
    fi

    if [ ! -e "${file_name}" ]; then
        echo "Copying ${file_name} from ${name} to ${PWD}/${file_name}..."
        qvm-run --pass-io "${name}" "cat ${path}/${file_name}" > "${PWD}/${file_name}"
    fi

    package_name="$(echo "${file_name}" | sed -r "s/(${version}).+$//")"

    if sudo yum $YUM_OPTS list installed "$package_name" >/dev/null 2>&1 ; then
        echo "Uninstalling package ${package_name}..."
        sudo yum $YUM_OPTS erase "$package_name"
    fi

    echo "Installing file ${file_name}..."
    if sudo yum $YUM_OPTS install "${file_name}" ; then
        echo "Deleting ${PWD}/${file_name}..."
        rm -f "${file_name}"
    fi
done

echo "Done."
