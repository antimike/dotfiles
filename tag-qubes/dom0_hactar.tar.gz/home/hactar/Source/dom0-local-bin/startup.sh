#!/bin/bash

ws-backgrounds > /dev/null 2>&1 &
i3altlayout > /dev/null 2>&1 & 
