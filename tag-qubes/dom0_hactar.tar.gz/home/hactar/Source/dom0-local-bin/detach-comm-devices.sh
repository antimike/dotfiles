#!/bin/bash

qvm-device usb detach $1 sys-usb:4-13
qvm-device usb detach $1 sys-usb:4-7
