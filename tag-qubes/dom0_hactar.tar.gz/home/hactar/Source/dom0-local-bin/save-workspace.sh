#!/bin/bash

i3-save-tree --workspace $1 > ~/.i3/layout-workspace/${2}.json
