#!/bin/bash

MONITOR_NAME="eDP1"
SAVE_DIR="$HOME/.i3/layout-desktop"

ADD_NEWLINES_RX='N'
PURGE_STANDALONE_COMMENTS_RX='s/\/\/.*[^,"]\n/\r/g'
UNCOMMENT_SELECTED_TITLE_ATTRS_RX='s/\/\/\s\+\("title":.*joplin.*terminal.*"\)/1/g'
PURGE_REMAINING_INSTANCE_AND_TITLE_LINES_RX='s/\s\+\/\/\s\+\("instance"\|"title"\).*\n//g'
UNCOMMENT_CLASS_LINES_RX='s/\/\/\s\+\("class".*\)/\1/g'
TRIM_COMMAS_RX='s/,\(\_s\+}\)/\1/g'

function make_tree_file() {
	local TODAY="$(date)"
	mkdir "$SAVE_DIR/$TODAY"
	TREE="$SAVE_DIR/$TODAY/$TODAY.json"
	i3-save-tree --output $MONITOR_NAME > $TREE
}


make_tree_file()


while IFS="" read -r p || [[ -n "$p" ]]; do
	# something with $p
done; < $TREE





i3-save-tree --output $MONITOR_NAME\
	| sed -e 's/\/\/.*[^,"]\n/\r/g'\
	| sed -e 's/\/\/\s\+\("title":.*joplin.*terminal.*"\)/\1/g'\
	| sed -e 's/\s\+\/\/\s\+\("instance"\|"title"\).*\n//g'\
	| sed -e 's/,\(\_s\+}\)/\1/g'\
	| sed -e 's/\/\/\s\+\("class".*\)/\1/g'\
	> "$SAVE_DIR/${1}.json"
