#!/bin/bash

feh --bg-tile --randomize /usr/share/backgrounds/favorites
