#!/bin/bash

qvm-device usb attach $1 sys-usb:4-13
qvm-device usb attach $1 sys-usb:4-7
