#!/bin/bash

i3-msg "append_layout ~/.i3/layout-desktop/$1.json"
